/**
 * Canonical legal state transitions.
 * Every state mutation in the system must go through isValidTransition().
 */

type DealState =
  | "created"
  | "funded"
  | "shipped"
  | "delivered"
  | "complete"
  | "disputed"
  | "cancelled"
  | "refunded";

const LEGAL_TRANSITIONS: Record<DealState, DealState[]> = {
  created: ["funded", "cancelled"],
  funded: ["shipped", "disputed", "cancelled", "refunded"],
  shipped: ["delivered", "disputed"],
  delivered: ["complete", "disputed"],
  complete: [],
  disputed: ["complete", "refunded"],
  cancelled: [],
  refunded: [],
};

export function isValidTransition(from: string, to: string): boolean {
  const allowed = LEGAL_TRANSITIONS[from as DealState];
  if (!allowed) return false;
  return allowed.includes(to as DealState);
}

export function assertValidTransition(from: string, to: string): void {
  if (!isValidTransition(from, to)) {
    throw new Error(`Illegal state transition: ${from} → ${to}`);
  }
}
