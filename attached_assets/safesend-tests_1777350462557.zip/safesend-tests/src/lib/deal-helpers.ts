import { randomUUID } from "crypto";

export const MAX_AMOUNT_NZD = 2500;
const FEE_RATE = 0.04;
const MIN_FEE_NZD = 5;

export function calculateFee(amountNzd: number): { feeNzd: number; totalNzd: number } {
  const feeNzd = Math.max(amountNzd * FEE_RATE, MIN_FEE_NZD);
  const totalNzd = amountNzd + feeNzd;
  return { feeNzd: Math.round(feeNzd * 100) / 100, totalNzd: Math.round(totalNzd * 100) / 100 };
}

export function validateAmount(amountNzd: number): string | null {
  if (amountNzd < 1) return "Amount must be at least $1 NZD";
  if (amountNzd > MAX_AMOUNT_NZD)
    return `Amount cannot exceed $${MAX_AMOUNT_NZD} NZD. For larger transactions please use Escrow.com`;
  return null;
}

export function generateDealId(): string {
  return randomUUID();
}

/** Convert NZD to Stripe cents (integer) */
export function nzdToCents(nzd: number): number {
  return Math.round(nzd * 100);
}
