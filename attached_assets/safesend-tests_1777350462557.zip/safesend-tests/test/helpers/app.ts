/**
 * Test app helper.
 * Imports the production app.ts and exposes it for supertest.
 *
 * The helper sets up a minimal env so the imports don't throw at module load,
 * and clears DB tables between tests so suites don't pollute each other.
 */
import { config } from "dotenv";
config({ path: ".env.test" });

// Sanity — fail fast if test env isn't configured
if (!process.env.TEST_DATABASE_URL) {
  throw new Error(
    "TEST_DATABASE_URL not set. Create .env.test pointing at a SEPARATE database — tests truncate tables.",
  );
}
if (!process.env.STRIPE_TEST_SECRET_KEY) {
  throw new Error("STRIPE_TEST_SECRET_KEY not set in .env.test");
}
if (!process.env.STRIPE_WEBHOOK_SECRET) {
  throw new Error("STRIPE_WEBHOOK_SECRET not set in .env.test (any non-empty string is fine)");
}

// Point the production code at the test DB — must happen BEFORE app import
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL;

// Now safe to import — env is set
// (Note: adjust paths if you put the test/ folder somewhere other than artifacts/api-server/test/)
import app from "../../src/app";
import { db, dealsTable, stateTransitionsTable, sellersTable, trackingEventsTable, idempotencyKeysTable } from "@workspace/db";

export { app };

/**
 * Truncate all tables. Run in beforeEach so tests are isolated.
 * Order matters — child tables first.
 */
export async function resetDb(): Promise<void> {
  await db.delete(stateTransitionsTable);
  await db.delete(trackingEventsTable);
  await db.delete(idempotencyKeysTable);
  await db.delete(dealsTable);
  await db.delete(sellersTable);
}

export { db, dealsTable, stateTransitionsTable, sellersTable, trackingEventsTable, idempotencyKeysTable };
