/**
 * Integration tests for the deals API.
 *
 * Run with a test database. Stripe calls go to Stripe test mode — they're real
 * but use fake cards. The cost of running these is zero (test mode) and they
 * catch genuine bugs.
 */
import { beforeEach, describe, expect, it } from "vitest";
import request from "supertest";
import { app, resetDb, db, dealsTable } from "../helpers/app";
import { seedDeal, seedSeller } from "../helpers/db";
import { eq } from "drizzle-orm";

beforeEach(async () => {
  await resetDb();
});

describe("POST /api/deals — create deal", () => {
  it("creates a deal and returns 201 with full payload", async () => {
    const res = await request(app)
      .post("/api/deals")
      .send({
        title: "Gibson Les Paul Studio",
        description: "Mid-2010s, mahogany body, scratch on the back",
        amountNzd: 850,
        buyerEmail: "buyer@test.local",
        sellerEmail: "seller@test.local",
      });
    expect(res.status).toBe(201);
    expect(res.body.id).toBeDefined();
    expect(res.body.amountNzd).toBe(850);
    expect(res.body.feeNzd).toBe(34); // 4% of 850
    expect(res.body.totalNzd).toBe(884);
    expect(res.body.state).toBe("created");
    expect(res.body.version).toBe(0);
  });

  it("rejects amount above the $2500 cap", async () => {
    const res = await request(app)
      .post("/api/deals")
      .send({
        title: "Too expensive",
        description: "This should be rejected per the platform cap",
        amountNzd: 5000,
        buyerEmail: "buyer@test.local",
        sellerEmail: "seller@test.local",
      });
    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/Escrow\.com/);
  });

  it("rejects when buyer and seller emails match (case-insensitive)", async () => {
    const res = await request(app)
      .post("/api/deals")
      .send({
        title: "Self-deal",
        description: "Buyer and seller cannot be the same person",
        amountNzd: 100,
        buyerEmail: "person@test.local",
        sellerEmail: "PERSON@test.local",
      });
    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/cannot be the same/);
  });

  it("rejects missing required fields with a clear error", async () => {
    const res = await request(app).post("/api/deals").send({ title: "incomplete" });
    expect(res.status).toBe(400);
  });
});

describe("GET /api/deals — list", () => {
  it("returns deals filtered by buyer email", async () => {
    await seedDeal({ buyerEmail: "alice@test.local", sellerEmail: "bob@test.local" });
    await seedDeal({ buyerEmail: "carol@test.local", sellerEmail: "bob@test.local" });
    const res = await request(app).get("/api/deals?email=alice@test.local&role=buyer");
    expect(res.status).toBe(200);
    expect(res.body).toHaveLength(1);
    expect(res.body[0].buyerEmail).toBe("alice@test.local");
  });

  it("returns empty array when no matches", async () => {
    const res = await request(app).get("/api/deals?email=nobody@test.local&role=buyer");
    expect(res.status).toBe(200);
    expect(res.body).toEqual([]);
  });
});

describe("GET /api/deals/:dealId — get one", () => {
  it("returns the deal", async () => {
    const deal = await seedDeal();
    const res = await request(app).get(`/api/deals/${deal.id}`);
    expect(res.status).toBe(200);
    expect(res.body.id).toBe(deal.id);
  });

  it("404 on unknown id", async () => {
    const res = await request(app).get("/api/deals/00000000-0000-0000-0000-000000000000");
    expect(res.status).toBe(404);
  });
});

describe("POST /api/deals/:id/mark-shipped — seller action", () => {
  it("only the seller can mark shipped (403 otherwise)", async () => {
    const deal = await seedDeal({
      state: "funded",
      buyerEmail: "buyer@x.com",
      sellerEmail: "seller@x.com",
    });

    // Buyer trying to mark shipped — denied
    const res1 = await request(app)
      .post(`/api/deals/${deal.id}/mark-shipped`)
      .send({ sellerEmail: "buyer@x.com", trackingNumber: "T123", courierSlug: "nzpost" });
    expect(res1.status).toBe(403);

    // Random third party — denied
    const res2 = await request(app)
      .post(`/api/deals/${deal.id}/mark-shipped`)
      .send({ sellerEmail: "stranger@x.com", trackingNumber: "T123", courierSlug: "nzpost" });
    expect(res2.status).toBe(403);

    // Real seller — allowed
    const res3 = await request(app)
      .post(`/api/deals/${deal.id}/mark-shipped`)
      .send({ sellerEmail: "seller@x.com", trackingNumber: "T123", courierSlug: "nzpost" });
    expect(res3.status).toBe(200);
    expect(res3.body.state).toBe("shipped");
    expect(res3.body.version).toBe(1);
  });

  it("blocks marking shipped from a non-funded state", async () => {
    const deal = await seedDeal({ state: "created" });
    const res = await request(app)
      .post(`/api/deals/${deal.id}/mark-shipped`)
      .send({ sellerEmail: deal.sellerEmail, trackingNumber: "T", courierSlug: "nzpost" });
    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/Cannot mark shipped/);
  });
});

describe("POST /api/deals/:id/dispute — either party", () => {
  it("buyer can raise dispute", async () => {
    const deal = await seedDeal({ state: "shipped", trackingNumber: "T1", courierSlug: "nzpost" });
    const res = await request(app)
      .post(`/api/deals/${deal.id}/dispute`)
      .send({ raisedByEmail: deal.buyerEmail, reason: "Item not as described" });
    expect(res.status).toBe(200);
    expect(res.body.state).toBe("disputed");
  });

  it("third party cannot raise dispute (403)", async () => {
    const deal = await seedDeal({ state: "funded" });
    const res = await request(app)
      .post(`/api/deals/${deal.id}/dispute`)
      .send({ raisedByEmail: "interloper@x.com", reason: "I'm not even involved" });
    expect(res.status).toBe(403);
  });

  it("blocks disputing a complete deal", async () => {
    const deal = await seedDeal({ state: "complete" });
    const res = await request(app)
      .post(`/api/deals/${deal.id}/dispute`)
      .send({ raisedByEmail: deal.buyerEmail, reason: "Too late" });
    expect(res.status).toBe(400);
  });
});

describe("POST /api/deals/:id/cancel", () => {
  it("either party can cancel a 'created' deal", async () => {
    const deal = await seedDeal({ state: "created" });
    const res = await request(app)
      .post(`/api/deals/${deal.id}/cancel`)
      .send({ requestedByEmail: deal.buyerEmail });
    expect(res.status).toBe(200);
    expect(res.body.state).toBe("cancelled");
  });

  it("blocks cancelling a shipped deal — must dispute instead", async () => {
    const deal = await seedDeal({ state: "shipped" });
    const res = await request(app)
      .post(`/api/deals/${deal.id}/cancel`)
      .send({ requestedByEmail: deal.buyerEmail });
    expect(res.status).toBe(400);
  });
});

describe("end-to-end happy path", () => {
  it("created → funded → shipped → delivered → complete with version increments", async () => {
    await seedSeller({ email: "seller@e2e.local", chargesEnabled: true, payoutsEnabled: true });

    // 1. Create
    const create = await request(app)
      .post("/api/deals")
      .send({
        title: "Camera lens",
        description: "Canon 50mm 1.8 — basically new",
        amountNzd: 200,
        buyerEmail: "buyer@e2e.local",
        sellerEmail: "seller@e2e.local",
      });
    expect(create.status).toBe(201);
    const dealId = create.body.id;
    expect(create.body.version).toBe(0);

    // 2. Simulate funding by directly setting state — production would go through Stripe webhook
    await db
      .update(dealsTable)
      .set({ state: "funded", fundedAt: new Date(), stripePaymentIntentId: "pi_test_e2e", version: 1 })
      .where(eq(dealsTable.id, dealId));

    // 3. Seller ships
    const ship = await request(app)
      .post(`/api/deals/${dealId}/mark-shipped`)
      .send({ sellerEmail: "seller@e2e.local", trackingNumber: "EE123NZ", courierSlug: "nzpost" });
    expect(ship.status).toBe(200);
    expect(ship.body.state).toBe("shipped");
    expect(ship.body.version).toBe(2);

    // 4. Simulate delivery via direct DB update
    await db
      .update(dealsTable)
      .set({ state: "delivered", deliveredAt: new Date(), version: 3 })
      .where(eq(dealsTable.id, dealId));

    // 5. Buyer releases funds
    const release = await request(app)
      .post(`/api/deals/${dealId}/release-funds`)
      .send({ buyerEmail: "buyer@e2e.local" });
    expect(release.status).toBe(200);
    expect(release.body.state).toBe("complete");
    expect(release.body.version).toBe(4);
  });
});
