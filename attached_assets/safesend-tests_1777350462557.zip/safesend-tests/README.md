# SafeSend test suite

A drop-in test suite for the SafeSend escrow API. Designed to give confidence
that money paths, state transitions, and webhook security are actually correct.

## What's here

```
test/
├── unit/                # Pure-function tests — no DB, no Stripe needed
│   ├── state-machine.test.ts   (80 tests)
│   └── deal-helpers.test.ts    (15 tests)
├── security/            # Webhook signature validation
│   └── webhook-signatures.test.ts
├── integration/         # Full HTTP API — needs DB + Stripe test keys
│   ├── deals.test.ts
│   ├── sellers.test.ts
│   ├── admin.test.ts
│   └── webhooks.test.ts
├── concurrency/         # Optimistic-lock proof tests
│   └── version-conflict.test.ts
└── helpers/             # Test fixtures, DB setup, mocked Stripe
    ├── app.ts
    ├── db.ts
    └── stripe-mock.ts
```

## Run order

```bash
# Step 1 — pure functions (always run first, fastest signal)
pnpm test:unit

# Step 2 — webhook signature security (no real Stripe calls)
pnpm test:security

# Step 3 — full integration (needs TEST_DATABASE_URL + STRIPE_TEST_SECRET_KEY)
pnpm test:integration

# Step 4 — concurrency stress (needs TEST_DATABASE_URL)
pnpm test:concurrency
```

## How to install in the existing repo

1. Copy the `test/` folder into `artifacts/api-server/test/`.
2. Add to `artifacts/api-server/package.json`:
   ```json
   "scripts": {
     "test": "vitest run",
     "test:watch": "vitest",
     "test:unit": "vitest run test/unit",
     "test:security": "vitest run test/security",
     "test:integration": "vitest run test/integration",
     "test:concurrency": "vitest run test/concurrency"
   },
   "devDependencies": {
     "vitest": "^1.6.0",
     "supertest": "^7.0.0",
     "@types/supertest": "^6.0.2"
   }
   ```
3. `pnpm install`
4. Set test env vars in `.env.test`:
   ```
   TEST_DATABASE_URL=postgres://...    (a SEPARATE Postgres instance — tests truncate tables)
   STRIPE_TEST_SECRET_KEY=sk_test_...
   STRIPE_WEBHOOK_SECRET=whsec_...     (any string for the security tests)
   TRACKINGMORE_API_KEY=test_key
   PORT=5000
   ```

## What this catches

- **State-machine drift** — every illegal transition is locked down by a test.
  If an agent later "improves" the legal-transitions table, the tests will
  scream.
- **Money math drift** — fee calc, $5 minimum, NZD-to-cents (the floating-point
  trap is explicitly tested with `0.1 + 0.2`).
- **Webhook spoofing** — Stripe and TrackingMore webhooks are tested with both
  valid and forged signatures. Forged signatures must return 400/401.
- **Idempotency** — same Stripe event delivered twice must process exactly once.
- **Authorization** — only the buyer can confirm payment; only the seller can
  mark shipped; only buyer or seller can dispute.
- **Concurrent-modification** — two simultaneous state transitions on the same
  deal: one wins, one fails with 409, no money double-moves.

## What this does NOT catch

These are out of scope and need separate effort:

- **Stripe Connect E2E** — actual card flow against Stripe test mode. Use
  Stripe's CLI: `stripe trigger payment_intent.succeeded`.
- **End-to-end browser flow** — Playwright or similar.
- **Production AML / fraud rules** — these don't exist in code yet.
- **Load / performance** — single-request semantics only.
